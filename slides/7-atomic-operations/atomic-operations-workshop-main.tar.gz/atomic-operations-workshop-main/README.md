```shell
docker run --rm \
-u "$(id -u):$(id -g)" \
-v $(pwd):/var/www/html \
-v ~/.composer/auth.json:/.composer/auth.json \
-w /var/www/html \
laravelsail/php83-composer:latest \
composer install --ignore-platform-reqs
```
```shell
./vendor/bin/sail npm i
```

Once installed, run project with
```shell
./vendor/bin/sail up
```

# TASK 1

Our application receives a lot of traffic and we have to register each user only once to the external api.
RegisterUserJob class works well, but it crashes as some users are registered twice.

```shell
./vendor/bin/sail artisan task-1
```



# TASK 2

We want to crawl all the users from an external api as fast as possible.
Current ReadAndMergeUsersJob works well with 1 worker, but it's too slow and it crashes with more workers. 

```shell
./vendor/bin/sail artisan task-2
```

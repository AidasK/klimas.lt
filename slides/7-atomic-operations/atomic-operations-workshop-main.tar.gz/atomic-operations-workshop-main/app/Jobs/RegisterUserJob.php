<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Actions\RegisterUserAtSomeExternalServiceViaApi;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;

class RegisterUserJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        private readonly int $userId
    ) {}

    public function handle(RegisterUserAtSomeExternalServiceViaApi $registerUser): void
    {
        // FIX THIS FILE TO MAKE IT CONCURRENTLY SAFE
        if (!Cache::get("$this->userId")) {
            $registerUser($this->userId);
            Cache::put("$this->userId", true);
        }
    }
}

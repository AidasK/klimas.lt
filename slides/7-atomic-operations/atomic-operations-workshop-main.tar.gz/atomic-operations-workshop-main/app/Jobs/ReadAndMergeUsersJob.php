<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Actions\ReadUsersFromSomeExternalServiceViaApi;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Cache;

class ReadAndMergeUsersJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(
        private readonly int $page
    ) {}

    public function handle(ReadUsersFromSomeExternalServiceViaApi $readUsers): void
    {
        // FIX THIS FILE TO MAKE IT CONCURRENTLY SAFE
        $allUsers = Cache::get('all-users') ?: [];
        $usersInPage = $readUsers($this->page);
        Cache::put('all-users', array_merge($allUsers, $usersInPage));
    }
}

<?php

use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/balance', function () {
    return Account::query()->get();
})->name('balance');

Route::post('/add', function (Request $request) {
    $account = Account::query()->where('name', $request->get('account'))->firstOrFail();
    $amount = $request->get('amount');

    // @TODO place your implementation here

    return response('ok', 200);
})->name('add');

Route::get('/', function () {
    return <<<HTML
<h1>Welcome to Database transactions workshop.</h1>
<h3>The only file you need to edit is <code>routes/web.php</code></h3>
HTML;
});

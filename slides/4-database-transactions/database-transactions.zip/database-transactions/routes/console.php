<?php

use App\Models\Account;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Http;

Artisan::command('concurrency:test {--requests=20}', function () {
    $this->info("Running `migrate:fresh --seed`");
    Artisan::call('migrate:fresh --seed');

    $nRequests = $this->option('requests');
    $url = 'http://dbt_nginx' . route('add', [], false);
    $this->info("Executing concurrently $url");
    $responses = Http::pool(function (\Illuminate\Http\Client\Pool $pool) use($url, $nRequests) {
        return collect(range(1, $nRequests))->map(fn () =>
           $pool->post(
               $url,
               ['account' => 'rapolas', 'amount' => 1]
           )
       );
    });
    $stats = [];
    /** @var \Illuminate\Http\Response $response */
    foreach ($responses as $response) {
        $stats[$response->status()] ??= 0;
        $stats[$response->status()]++;
    }
    $this->table(['status code', 'count'], collect($stats)->map(fn ($count, $status) => [$status, $count]));
    $rapolas = Account::query()->where('name', 'rapolas')->first();
    $this->table(['id', 'name', 'money'], [$rapolas->toArray()]);
    $expectedBalance = 100 + $nRequests;
    $this->newline();
    if ($rapolas->balance != $expectedBalance) {
        $this->error("Test failed, after $nRequests requests, account balance should be $expectedBalance");
    } elseif($nRequests > 10) {
        $this->line(<<<HOORAY
                   ___..-.---.---.--..___
               _..-- `.`.   `.  `.  `.      --.._
              /    ___________\   \   \______    \
              |   |.-----------`.  `.  `.---.|   |
              |`. |'  \`.        \   \   \  '|   |
              |`. |'   \ `-._     `.  `.  `.'|   |
             /|   |'    `-._o)\  /(o\   \   \|   |\
           .' |   |'  `.     .'  '.  `.  `.  `.  | `.
          /  .|   |'    `.  (_.==._)   \   \   \ |.  \         _.--.
        .' .' |   |'    . _.-======-._ .`.  `.  `. `. `.    _.-_.-'\\
       /  /   |   |'    \    |_||_|   /   \   \   \  \  \ .'_.'     ||
      / .'    |`. |'      -'========`-     `.  `-._`._`. \(.__      :|
     ( '      |`. |'.______________________.'\      _.) ` )`-._`-._/ /
      \\      |   '.------------------------.'`-._-'    //     `-._.'
      _\\_    \    | HOORAY, YOU DID IT!`.`.|    '     //
     (_  _)    '-._|________________________|_.-'|   _//_
     /  /      /`-._      |`-._     / /      /   |  (_  _)
   .'   \     |`-._ `-._   `-._`-._/ /      /    |    \  \
  /      `.   |    `-._ `-._   `-._|/      /     |    /   `.
 /  / / /. )  |  `-._  `-._ `-._          /     /   .'      \
| | | \ \|/   |  `-._`-._  `-._ `-._     /     /.  ( .\ \ \  \
 \ \ \ \/     |  `-._`-._`-._  `-._ `-._/     /  \  \|/ / | | |
  `.\_\/       `-._  `-._`-._`-._  `-._/|    /|   \   \/ / / /
              /    `-._  `-._`-._`-._  ||   / |    \   \/_/.'
            .'         `-._  `-._`-._  ||  /  |     \
           /           / . `-._  `-._  || /   |      \
          '\          / /      `-._    ||/'._.'       \
           \`.      .' /           `-._|/              \
            `.`-._.' .'               \               .'
              `-.__\/                 `\            .' '
                                       \`.       _.' .'
                                        `.`-._.-' _.'
                                          `-.__.-'
HOORAY
);
    } else {
        $this->error('Common, you can do it with more requests');
    }
})->purpose('Test concurrency');

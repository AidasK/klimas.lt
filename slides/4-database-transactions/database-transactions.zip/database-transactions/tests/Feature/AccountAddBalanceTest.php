<?php

namespace Tests\Feature;

use Database\Seeders\AccountSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AccountAddBalanceTest extends TestCase
{
    use RefreshDatabase;

    public function test_if_account_balance_can_be_added_0()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/add?account=rapolas&amount=0');
        $response->assertStatus(200);
        $this->assertDatabaseHas('accounts', [
            'name' => 'rapolas',
            'balance' => 100,
        ]);
    }

    public function test_if_account_balance_can_be_added_negative()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/add?account=rapolas&amount=-1');
        $response->assertStatus(200);
        $this->assertDatabaseHas('accounts', [
            'name' => 'rapolas',
            'balance' => 99,
        ]);
    }

    public function test_if_account_balance_can_not_go_negative()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/add?account=rapolas&amount=-101');
        $response->assertStatus(400);
        $this->assertDatabaseHas('accounts', [
            'name' => 'rapolas',
            'balance' => 100,
        ]);
    }

    public function test_if_account_balance_can_increase()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/add?account=rapolas&amount=101');
        $response->assertStatus(200);
        $this->assertDatabaseHas('accounts', [
            'name' => 'rapolas',
            'balance' => 201,
        ]);
    }

}

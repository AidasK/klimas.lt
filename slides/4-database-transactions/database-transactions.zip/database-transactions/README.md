Get ready, run these commands:
```shell
cp .env.example .env
docker compose up -d 
docker exec -ti database-transactions-php-1 composer install
docker exec -ti database-transactions-php-1 php artisan migrate:fresh --seed
```

Now go to routes/web.php and complete your task there.

Test if you have completed this task by running:
```shell
docker exec -ti database-transactions-php-1 php artisan test
```

Test if you have completed a concurrency task:
```shell
docker exec -ti database-transactions-php-1 php artisan concurrency:test
```

<?php

declare(strict_types=1);

namespace Tests\Feature;

use Database\Seeders\AccountSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AccountTransferBalanceTest extends TestCase
{
    use RefreshDatabase;

    /**
     * @dataProvider transferTestCases
     */
    public function test_if_account_balance_transfer(
        string $from,
        string $to,
        int $amount,
        int $expectedStatus,
        ?int $expectedFromBalance,
        ?int $expectedToBalance,
    )
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post("/transfer?from=$from&to=$to&amount=$amount");
        $response->assertStatus($expectedStatus);
        if ($expectedFromBalance !== null) {
            $this->assertDatabaseHas('accounts', [
                'name' => $from,
                'balance' => $expectedFromBalance,
            ]);
        }
        if ($expectedToBalance !== null) {
            $this->assertDatabaseHas('accounts', [
                'name' => $to,
                'balance' => $expectedToBalance,
            ]);
        }
    }

    public function transferTestCases()
    {
        return [
            [
                'from' => 'Rapolas',
                'to' => 'Vladelis',
                'amount' => 0,
                'expectedStatus' => 200,
                'expectedFromBalance' => 100,
                'expectedToBalance' => 100,
            ],
            [
                'from' => 'Rapolas',
                'to' => 'Vladelis',
                'amount' => 1,
                'expectedStatus' => 200,
                'expectedFromBalance' => 99,
                'expectedToBalance' => 101,
            ],
            [
                'from' => 'Rapolas',
                'to' => 'Vladelis',
                'amount' => -2,
                'expectedStatus' => 200,
                'expectedFromBalance' => 102,
                'expectedToBalance' => 98,
            ],
            [
                'from' => 'Rapolas',
                'to' => 'Vladelis',
                'amount' => 100,
                'expectedStatus' => 200,
                'expectedFromBalance' => 0,
                'expectedToBalance' => 200,
            ],
            [
                'from' => 'Rapolas',
                'to' => 'Vladelis',
                'amount' => 101,
                'expectedStatus' => 400,
                'expectedFromBalance' => 100,
                'expectedToBalance' => 100,
            ],
            [
                'from' => 'Rapolas',
                'to' => 'Vladelis',
                'amount' => -1000,
                'expectedStatus' => 400,
                'expectedFromBalance' => 100,
                'expectedToBalance' => 100,
            ],
            [
                'from' => 'Rapolas',
                'to' => 'Some not existent account',
                'amount' => 1,
                'expectedStatus' => 404,
                'expectedFromBalance' => 100,
                'expectedToBalance' => null,
            ],
        ];
    }
}

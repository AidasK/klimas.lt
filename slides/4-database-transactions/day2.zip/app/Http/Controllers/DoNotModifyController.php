<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DoNotModifyController
{
    public function __invoke(Request $request)
    {
        return DB::transaction(function () use ($request) {
            $one = $request->get('one');
            $two = $request->get('two');
            if (rand(0, 1)) {
                $one = $request->get('two');
                $two = $request->get('one');
            }
            Account::query()
                ->where('name', $one)
                ->lock()
                ->firstOrFail();
            Account::query()
                ->where('name', $two)
                ->lock()
                ->firstOrFail();
            return response('lock', 200);
        }, 5);
    }
}
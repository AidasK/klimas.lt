<?php

declare(strict_types=1);

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\File;
use Throwable;

class FileChannel
{
    public function send($notifiable, Notification $notification)
    {
        $name = $notification->toFileName($notifiable);
        try {
            mkdir(storage_path('notifications'));
        } catch (Throwable) {

        }
        file_put_contents(storage_path("notifications/$name"), time());
    }

    public function clearNotifications()
    {
        $path = storage_path('notifications');
        File::deleteDirectory($path);
    }

    public function countNotifications()
    {
        $path = storage_path('notifications');
        return count(file_exists($path) ? File::allFiles($path) : []);
    }
}
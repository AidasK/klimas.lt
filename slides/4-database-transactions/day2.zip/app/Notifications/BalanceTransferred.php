<?php

namespace App\Notifications;

use App\Broadcasting\File;
use App\Models\Account;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class BalanceTransferred extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct()
    {
        // do not edit, nothing is needed here
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return [
            FileChannel::class
        ];
    }

    public function toFileName(Account $notifiable)
    {
        return uniqid($notifiable->name);
    }
}

<?php

declare(strict_types=1);

use App\Http\Controllers\DoNotModifyController;
use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/transfer', function (Request $request) {
    return \Illuminate\Support\Facades\DB::transaction(function () use ($request) {
        $from = Account::query()
            ->lockForUpdate()
            ->where('name', $request->get('from'))
            ->firstOrFail();
        $to = Account::query()
            ->lockForUpdate()
            ->where('name', $request->get('to'))
            ->firstOrFail();
        $amount = $request->get('amount');
        $from->balance -= $amount;
        if ($from->balance < 0) {
            return response('', 400);
        }
        $to->balance += $amount;
        if ($to->balance < 0) {
            return response('', 400);
        }
        $from->save();
        $to->save();
        return response('ok', 200);
    }, 5);
})->name('transfer');

Route::get('/', function () {
    return <<<HTML
<h1>Welcome to Database transactions day 2 workshop.</h1>
<h3>The only file you need to edit is <code>routes/web.php</code></h3>
HTML;
});

Route::post('/some-unrelated-route-nothing-to-do-here', DoNotModifyController::class)
    ->name('some-locking');

<?php

use App\Models\Account;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

Artisan::command('concurrency:test {--requests=4} {--cycles=5}', function () {
    $this->info("Running `migrate:fresh --seed`");
    Artisan::call('migrate:fresh --seed');

    $nRequests = $this->option('requests');
    $cycles = $this->option('cycles');
    $url = 'http://dbt_day2_nginx' . route('transfer', [], false);
    $this->info("Executing concurrently $url");
    $stats = [];
    for ($c = 0; $c < $cycles; $c++) {
        $responses = Http::pool(function (\Illuminate\Http\Client\Pool $pool) use ($url, $nRequests) {
            return collect(range(1, $nRequests))
                ->map(
                    fn () => [
                        $url,
                        ['from' => 'rapolas', 'to' => 'vladelis', 'amount' => 1]
                    ]
                )
                ->concat(collect(range(1, $nRequests))->map(
                    fn () => [
                        'http://dbt_day2_nginx' . route(
                            'some-locking',
                            ['one' => 'vladelis', 'two' => 'rapolas'],
                            false
                        )
                    ]
                ))
                ->shuffle()
                ->map(fn ($args) => $pool->post(...$args));
        });
        /** @var \GuzzleHttp\Psr7\Response $response */
        foreach ($responses as $response) {
            if ($response instanceof Throwable) {
                $this->error($response->getMessage());
                continue;
            }
            if ($response->getStatusCode() !== 200) {
                $this->info('API request failed with:');
                $this->error(Str::limit($response->getBody()->getContents(),500));
            }
            $stats[$response->getStatusCode()] ??= 0;
            $stats[$response->getStatusCode()]++;
        }
    }
    $this->table(['status code', 'count'], collect($stats)->map(fn ($count, $status) => [$status, $count]));
    $rapolas = Account::query()->where('name', 'rapolas')->first();
    $vladelis = Account::query()->where('name', 'vladelis')->first();
    $this->table(['id', 'name', 'money'], [$rapolas->toArray(), $vladelis->toArray()]);
    $expectedRapolasBalance = 100 - $nRequests * $cycles;
    $expectedVladelisBalance = 100 + $nRequests * $cycles;
    if (
        $rapolas->balance !== $expectedRapolasBalance &&
        $vladelis->balance !== $expectedVladelisBalance
    ) {
        $this->error("Test failed. Expected Rapolas balance $expectedRapolasBalance");
    } else {
        $this->line(<<<HOORAY
        
        ＼（＾○＾）人（＾○＾）／ 
               Hooray!
               
        HOORAY
        );
    }
})->purpose('Test transfer concurrency');
Get ready!
1. Make sure docker compose v2 is enabled by default. You can do this in the docker settings by checking `Use Docker Compose V2`. 
If it is, run these commands:

```shell
git clone --branch day-2-locks --single-branch git@gitlab.com:ekomlita/workshop/database-transactions.git database-transactions-day-2
cd database-transactions-day-2
cp .env.example .env
docker compose up -d 
docker exec -ti database-transactions-day-2-php-1 composer install
docker exec -ti database-transactions-day-2-php-1 php artisan migrate:fresh --seed
```

2. Now go to routes/web.php and complete your task there. Test if you have completed it by running:
```shell
docker exec -ti database-transactions-day-2-php-1 php artisan test
```

3. Test if you have completed a concurrency task:
```shell
docker exec -ti database-transactions-day-2-php-1 php artisan concurrency:test
```

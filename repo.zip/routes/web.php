<?php

use App\Models\Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return <<<HTML
<h1>Welcome to Database transactions workshop.</h1>
<h3>The only file you need to edit is <code>routes/web.php</code></h3>
HTML;
});
Route::get('/balance', function () {
    return Account::query()->get();
})->name('balance');

Route::post('/move', function (Request $request) {
    $from = Account::query()->where('person_name', $request->get('from'))->firstOrFail();
    $to = Account::query()->where('person_name', $request->get('to'))->firstOrFail();
    $amount = $request->get('amount');
    $from->money -= $amount;
    if ($from->money<0) {
        return response('ok', 400);
    }
    $to->money += $amount;
    $from->save();
    $to->save();
    return response('ok', 200);
})->name('move');

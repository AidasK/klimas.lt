Get ready, run these commands:
```shell
docker compose up -d 
docker exec -ti database-transactions-php-1 composer install
docker exec -ti database-transactions-php-1 php artisan migrate
docker exec -ti database-transactions-php-1 php artisan db:seed
```

Test if you have completed a basic task
```shell
docker exec -ti database-transactions-php-1 php artisan test
```

Test if you have completed a concurrency task
```shell
docker exec -ti database-transactions-php-1 php artisan concurrency:test
```

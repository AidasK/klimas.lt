<?php

namespace Tests\Feature;

use Database\Seeders\AccountSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MoveBalanceTest extends TestCase
{
    use RefreshDatabase;

    public function test_if_account_balance_can_be_moved_by_0()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/move?from=rapolas&to=einoras&amount=0');
        $response->assertStatus(200);
        $this->assertDatabaseHas('accounts', [
            'person_name' => 'rapolas',
            'money' => 100,
        ]);
        $this->assertDatabaseHas('accounts', [
            'person_name' => 'einoras',
            'money' => 100,
        ]);
    }

    public function test_if_account_balance_can_be_moved_by_10()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/move?from=rapolas&to=einoras&amount=10');
        $response->assertStatus(200);
        $this->assertDatabaseHas('accounts', [
            'person_name' => 'rapolas',
            'money' => 90,
        ]);
        $this->assertDatabaseHas('accounts', [
            'person_name' => 'einoras',
            'money' => 110,
        ]);
    }

    public function test_if_account_balance_can_not_be_moved_by_more_than_rapolas_has()
    {
        $this->seed(AccountSeeder::class);
        $response = $this->post('/move?from=rapolas&to=einoras&amount=200');
        $response->assertStatus(400);
        $this->assertDatabaseHas('accounts', [
            'person_name' => 'rapolas',
            'money' => 100,
        ]);
        $this->assertDatabaseHas('accounts', [
            'person_name' => 'einoras',
            'money' => 100,
        ]);
    }
}
